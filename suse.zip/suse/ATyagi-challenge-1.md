# Amal Tyagi: Challenge 1

## Prerequisites

In this tutorial you'll be deploying a simple application as a workload to a Kubernetes cluster. To complete the tutorial, you will need access to the following:
- A cloud account which supports deployment of containerized Kubernetes applications. We'll assume you have a Google Cloud account, but AWS, Microsoft, and Oracle also offer managed Kubernetes services.
- Docker installed (optional). Google Cloud Shell comes pre-installed with Docker, so this is only needed if you'd like to deploy the container locally. 


## Create A New Project

In the [Google Cloud console](https://console.cloud.google.com), create a new project. In this case, we name the project `suse-gke-cluster` which becomes the `PROJECT_ID` as well.

1. To create a new project, first view all projects.
![View all projects](0-create-project-0.png)
2. Click on "NEW PROJECT."
![Click "NEW PROJECT"](0-create-project-1.png)
3. Choose a new name, e.g. `suse-gke-cluster` and click "CREATE."
![Choose a name and click "CREATE"](0-create-project-2.png)
 

## Enable APIs and Check Billing

1. Enable the [Artifact Registry](https://console.cloud.google.com/marketplace/product/google/artifactregistry.googleapis.com) and [Google Kubernetes Engine API](https://console.cloud.google.com/marketplace/product/google/container.googleapis.com) by following the links provided.
2. Confirm that billing is enabled for this project by selecting "Billing" from the hamburger menu in the upper-left hand corner, and then "Manage" to see if your project is listed.


## Create A Repository

1. Click on the following notification to access the new project dashboard.
![Click on new project notification](1-create-repo-0.png)
2. In the console, click the Activate Cloud Shell button at the top the page. You'll see a new frame at the bottom of the page displaying a command-line prompt.
![Access the Cloud Shell](1-create-repo-1.png)
3. Set the PROJECT_ID environment variable to your Google Cloud project ID, for instance: `export PROJECT_ID=suse-gke-cluster` and then `echo $PROJECT_ID` to check that the variable has been set properly.
4. Set your project ID for the Google Cloud CLI as follows: `gcloud config set project $PROJECT_ID` which will output `Updated property [core/project].` once you've authorized your Google account.
5. Create the `hello-repo` repository by first finding an available region (`gcloud artifacts locations list`) and then replacing `REGION` with your region as shown: `gcloud artifacts repositories create hello-repo --repository-format=docker --location=us-west4 --description="Docker repository"`


## Build the Container Image
1. In the Cloud Shell, run `git clone https://github.com/go-training/helloworld` to copy the sample app into your repo.
2. See the sample Dockerfile [here](https://github.com/GoogleCloudPlatform/kubernetes-engine-samples/blob/main/hello-app/Dockerfile) for reference.
3. In the Cloud Shell, run `cd helloworld` to switch your working directory.
4. Run `touch Dockerfile` to create a new file and `vim Dockerfile` to edit that file.
5. Copy and paste the contents from step 1, switching all occurrences of `hello-app` to `helloworld` to match our app's name.
6. Run `docker build -t us-west4-docker.pkg.dev/${PROJECT_ID}/hello-repo/helloworld:v1 .` to build the image using your Dockerfile.
7. Run `docker images` to verify that the build was successful.


## Push Docker Image to Artifact Registry
1. Configure the Docker command-line tool and authenticate to Artifact Registry by running `gcloud auth configure-docker us-west4-docker.pkg.dev`.
2. Push the Docker image that you just built to the repository by running `docker push us-west4-docker.pkg.dev/${PROJECT_ID}/hello-repo/helloworld:v1`.


## Create a GKE Cluster
1. Set your Compute Engine region by running `gcloud config set compute/region us-west4`.
2. Create a cluster by running `gcloud container clusters create-auto hello-cluster`. This will take a few minutes.


## Deploy Your App to GKE
1. Ensure that you are connected to your GKE cluster by running `gcloud container clusters get-credentials hello-cluster --region us-west4`.
2. Create a Kubernetes Deployment for your Docker image by running `kubectl create deployment helloworld --image=us-west4-docker.pkg.dev/${PROJECT_ID}/hello-repo/helloworld:v1`.
3. Set the baseline number of Deployment replicas to 3 by running `kubectl scale deployment helloworld --replicas=3`.
4. Create a HorizontalPodAutoscaler resource for your Deployment by running `kubectl autoscale deployment helloworld --cpu-percent=80 --min=1 --max=5`.
5. To see the Pods created, run `kubectl get pods`. If any of the Pods does not have a `Status` value of `Running` you'll need to wait a few minutes before proceeding.


## Expose Your App to the Internet
1. Generate a Kubernetes Service for your Deployment by running `kubectl expose deployment helloworld --name=hello-app-service --type=LoadBalancer --port 80 --target-port 8080`.
2. Run `kubectl get service` to get the Service details. If the outputted `EXTERNAL-IP` is `<pending>`, wait a few minutes and try again.
3. Copy the outputted `EXTERNAL-IP` to a new browser tab and check that the proper message and hostname appear. If not, your cluster may still be updating. In the hamburger menu, click on "Kubernetes Engine" and "Clusters" to view the status of your clusters.


## Learn More

Visit the [Google Cloud documentation](https://cloud.google.com/kubernetes-engine/docs/tutorials/hello-app) to learn more about deploying containerized applications to GKE clusters, versioning, and cleaning up.