# Amal Tyagi: Challenge 2

## Justification

While there are several ways to triage and prioritize the issues in my backlog (first in, first out being the most basic), we employ a method to prioritize customers based on problem severity:
- HIGH priority: failed deployment or total loss of service
- MEDIUM priority: core features unavailable or slow service
- LOW priority: non-blocking technical asks or issues

Our justification behind this method is to prevent customer churn. We don't want pre-sales, or otherwise new, customers to consider alternatives, so we prioritize those who can't get started. On the other hand, customers asking in-depth questions about an already-working setup can wait so long as core services are available. (If we were provided with more information, e.g. the potential value of each customer engagement, we would need to factor it into our triage problem.)


## Initial Prioritization

Using our definitions of severity, we break down the provided issues as follows:
- 1--HIGH: While following an installation procedure, the customer runs into an issue which prevents them from using the service altogether.
- 2--MEDIUM: An already-existing customer is finding that core services are unavailable after a patch is installed.
- 3--LOW: The customer is asking about an external plugin, which is a relatively non-blocking technical ask. 
- 4--MEDIUM: The customer is facing a non-blocking technical issue and simply wishes to save time. To prevent slow service, we label this with MEDIUM priority. 
- 5--HIGH: Again, we find a customer with a failed deployment preventing our service from being used.


## Final Prioritization

Our next step is to prioritize between our 2 HIGH priority and 2 MEDIUM priority issues. We use the same justification as before (minimizing churn) to determine which issues to support first.

The final order of prioritization is as follows: 
- 1--HIGH: Since this issue occurred while a customer followed *our* docs, we should address it first and determine if escalation to our engineering team is necessary. 
- 5--HIGH: Since this issue occurs with AWS, we can potentially refer the customer to the logging & monitoring built into the AWS platform. So this is of slightly lower priority.
- 2--MEDIUM: Since the customer lacks access to core services, we place it above the customer simply looking to speed up their processes.
- 4--MEDIUM.
- 3--LOW.

So addressing problems in the order (1) (5) (2) (4) (3) will best ensure we reduce churn.